import 'dart:async';
import 'dart:convert';

import 'package:eshop_multivendor/Model/Section_Model.dart';
import 'package:eshop_multivendor/Screen/HomePage.dart';
import 'package:eshop_multivendor/Screen/Product_Detail.dart';
import 'package:eshop_multivendor/Screen/product_details2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:http/http.dart';

import '../Helper/Color.dart';
import '../Helper/Constant.dart';
import '../Helper/Session.dart';
import '../Helper/String.dart';
import '../Model/GetSameDayModel.dart';
import 'Favorite.dart';
import 'Login.dart';
import 'NotificationLIst.dart';
import 'Search.dart';
import 'package:http/http.dart'as http;
class SameProduct extends StatefulWidget {
  const SameProduct({Key? key}) : super(key: key);

  @override
  State<SameProduct> createState() => _SameProductState();
}

class _SameProductState extends State<SameProduct> {

  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 500),
        (){
      return getsameDay();
        }

    );

  }

  List<Product> productList = [];
  Product? product;

  Future getProductDetails(String id, int i) async {
    // _isNetworkAvail = await isNetworkAvailable();
    // if (_isNetworkAvail) {
      try {
        // if (notificationisloadmore) {
        //   if (mounted)
        //     setState(() {
        //       notificationisloadmore = false;
        //       notificationisgettingdata = true;
        //       if (notificationoffset == 0) {
        //         productList = [];
        //       }
        //     });

          var parameter = {
            // CATID: widget.model!.categoryId,
            // LIMIT: perPage.toString(),
            // OFFSET: notificationoffset.toString(),
            ID: id,
            // IS_SIMILAR: "1"
          };

          // if (CUR_USERID != null) parameter[USER_ID] = CUR_USERID;

          Response response =
          await post(getProductApi, headers: headers, body: parameter)
              .timeout(Duration(seconds: timeOut));
          print(getProductApi.toString());
          print(parameter.toString());

          var getdata = json.decode(response.body);

          bool error = getdata["error"];
          // String msg = getdata["message"];

          // notificationisgettingdata = false;
          // if (notificationoffset == 0) notificationisnodata = error;

          if (!error) {
            // totalProduct = int.parse(getdata["total"]);
            if (mounted) {
              new Future.delayed(
                  Duration.zero,
                      () => setState(() {
                    List mainlist = getdata['data'];
                    if (mainlist.length != 0) {
                      List<Product> items = [];
                      List<Product> allitems = [];

                      items.addAll(mainlist
                          .map((data) => new Product.fromJson(data))
                          .toList());

                      allitems.addAll(items);

                      for (Product item in items) {

                        productList
                            .where((i) => i.id == item.id)
                            .map((obj) {
                          allitems.remove(item);
                          product = productList[0];
                          return obj;

                        }).toList();
                      }
                      productList.addAll(allitems);
                      print("this is a ===========${productList[i]}");

                      Navigator.push(context, MaterialPageRoute(builder: (context)=>ProductDetail(
                        model:productList[i],
                         secPos: 0, index: 0, list: true

                      )));
                      // notificationisloadmore = true;
                      // notificationoffset = notificationoffset + perPage;
                    } else {
                      // notificationisloadmore = false;
                    }
                  }));
            }
          } else {
            // notificationisloadmore = false;
            if (mounted) if (mounted) setState(() {});
          }

      } on TimeoutException catch (_) {
        setSnackbar(getTranslated(context, 'somethingMSg')!, context);
        if (mounted)
          setState(() {
            // notificationisloadmore = false;
          });
      }
    // } else {
    //   if (mounted)
    //     setState(() {
    //       _isNetworkAvail = false;
    //     });
    // }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: colors.blackTemp,
      appBar : AppBar(
        shape: ContinuousRectangleBorder(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(100.0),
              topRight: Radius.circular(100.0)
          ),),
         backgroundColor: colors.primary,
        leadingWidth: 90, //TODO Adjust leading container width
        title: Text(
          'Same Day',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        actions: [
          Row(
            children: [
              IconButton(
                  icon: SvgPicture.asset(
                    imagePath + "search.svg",
                    height: 20,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Search(),
                        ));
                  }),

              IconButton(
                icon: SvgPicture.asset(
                  imagePath + "desel_notification.svg",
                  color: Colors.white,
                ),
                onPressed: () {
                  CUR_USERID != null
                      ? Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => NotificationList(),
                      ))
                      : Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Login(),
                      ));
                },
              ),
              IconButton(
                padding: EdgeInsets.all(0),
                icon: SvgPicture.asset(
                  imagePath + "desel_fav.svg",
                  color: Colors.white,
                ),
                onPressed: () {
                  CUR_USERID != null
                      ? Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Favorite(),
                      ))
                      : Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Login(),
                      ));
                },
              ),
            ],
          )
        ],
      ),
      body: getSame == null ?Center(child: CircularProgressIndicator()):Container(
        height: double.infinity,
        color: Color(0xffF3F3F3),
        child: getSame!.data!.product!.length == 0? SizedBox.shrink():GridView.count(
                 padding: EdgeInsetsDirectional.all(5),
                 crossAxisCount: 2,
                 shrinkWrap: true,
                 childAspectRatio: 0.75,
                 physics: NeverScrollableScrollPhysics(),
                 mainAxisSpacing: 5,
                 crossAxisSpacing: 5,
                     children: List.generate(getSame!.data!.product!.length, (index) {
                         return InkWell(
                           onTap: (){
                             getProductDetails(getSame!.data!.product![index].id.toString() , index);
                             // setState(() {
                             //
                             // });


                           },
                           child: Card(
                             shape: RoundedRectangleBorder(
                               borderRadius: BorderRadius.all(Radius.circular(10))
                             ),
                             child: Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 getSame!.data!.product![index].image == null || getSame!.data!.product![index].image == "" ? Image.asset("assets/images/placeholder.png"):Container(
                                   height: 140,
                                   width: double.infinity,
                                   child: ClipRRect(
                                     borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10)),
                                       child: Image.network("${getSame!.data!.product![index].image}",fit: BoxFit.fill,)),
                                 ),
                                 SizedBox(height: 10,),
                                 Container(
                                   width: 150,
                                     child: Padding(
                                       padding: const EdgeInsets.only(left: 10),
                                       child: Text("${getSame!.data!.product![index].name}",style: TextStyle(color: colors.blackTemp,),overflow: TextOverflow.ellipsis,),
                                     )),
                                 Padding(
                                   padding: const EdgeInsets.only(left: 10),
                                   child: Text("$CUR_CURRENCY " "${getSame!.data!.product![index].variants![0].price}",style: TextStyle(color: colors.blackTemp,fontWeight: FontWeight.bold),),
                                 ),
                                 Padding(
                                   padding: const EdgeInsets.only(left: 10),
                                   child: Text("$CUR_CURRENCY " "${getSame!.data!.product![index].variants![0].specialPrice}",style: TextStyle(color: colors.blackTemp,),),
                                 )

                               ],
                             ),
                           ),
                         );
                       }
            )
        ),
      )
    );

  }

  GetSameDayModel?  getSame;

  // getsamedayAll()async {
  //   var headers = {
  //     'Cookie': 'ci_session=76b7ded811e0731e4859f02f0e136a0348a1372b'
  //   };
  //   var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/get_products'));
  //   request.fields.addAll({
  //     'sort': 'p.id',
  //     'order': ' DESC',
  //     'limit': ' 10',
  //     'offset': ' 0',
  //     'top_rated_product': ' 0',
  //     'category_id': '${}',
  //     'user_id': '${CUR_USERID}'
  //   });
  //
  //   request.headers.addAll(headers);
  //
  //   http.StreamedResponse response = await request.send();
  //
  //   if (response.statusCode == 200) {
  //     final result = await response.stream.bytesToString();
  //     var finalData = Product.fromJson(jsonDecode(result));
  //     setState(() {
  //       getSame = finalData;
  //     });
  //   }
  //   else {
  //     print(response.reasonPhrase);
  //   }
  //
  // }

  getsameDay() async {
    var headers = {
      'Cookie': 'ci_session=ad18ddd3d39c36e4a5133393821fd5e87ee4112b'
    };
    var request = http.Request('GET', Uri.parse('$baseUrl/get_today_product'));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      final result = await response.stream.bytesToString();
      var finalData = GetSameDayModel.fromJson(jsonDecode(result));
      setState(() {
        getSame = finalData;
      });
    }
    else {
    print(response.reasonPhrase);
    }

  }

}

