#import <Flutter/Flutter.h>

@interface DownloadsPathProviderPlugin : NSObject<FlutterPlugin>
@end
